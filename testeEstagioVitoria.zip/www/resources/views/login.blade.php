@extends('templates.template')

@section('content')
<center>
    <h1>SchoolsAdmin</h1>
<div class="container"> 
 <div class="row">  
     @if($errors->any())
        <div class="alert alert-danger">
            <ul>
              @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
        </div>
      @endif
      
      @if(session('danger'))
        <div class="alert alert-danger">
          {{ session('danger') }}
        </div>
      @endif
     
  <div class="col-md-6 offset-md-3">
  <form method="POST" action="{{ url('/auth') }}" >
    @csrf
    <div class="col-4">
    <label for="formGroupExampleInput">Endereço de email</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email">
  </div>
<br>
  <div class="col-4">
    <label for="formGroupExampleInput2">Senha</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Senha">
  </div>
  <br>
  <button type="submit" class="btn btn-primary">Login</button>   
</form>
</div>
</div> 
</center>
@endsection