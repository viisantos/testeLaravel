@extends('templates.template')

@section('content')
<h3>Alterações feitas com sucesso</h3>
<a href="{{ url('/teste')}}"/> 
<button type="submit" class="btn btn-primary">
    Retornar a tela inicial
</button>
@endsection