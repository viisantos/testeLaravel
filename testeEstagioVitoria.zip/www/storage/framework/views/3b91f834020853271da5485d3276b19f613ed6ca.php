

<?php $__env->startSection('content'); ?>
    <h1 class="text-left" class="titulo">SchoolsAdmin</h1>

<div class="col-8 m-auto">
    <table class="table text-center">
        <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Localização</th>
                <th scope="col">Ação</th>
            </tr>   
        </thead>
        <tbody>
            <?php $__currentLoopData = $escola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escolas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"> <?php echo e($escolas->id); ?></th>
                <td><?php echo e($escolas->nome); ?></td>
                <td><?php echo e($escolas->localizacao); ?></td>
                
                <td>
                    <a href="<?php echo e(url("teste/$escolas->id")); ?>"/>
                    <button class="btn btn-dark">Visualizar Detalhes</button>
                        
                    <a href="<?php echo e(url("teste/$escolas->id/edit")); ?>"/>
                    <button class="btn btn-primary">Editar</button>
                       
                    <a href="<?php echo e(url("excluir/$escolas->id")); ?>"/>
                    <button class="btn btn-danger">Excluir</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
        </tbody>
        </table>
    
        <a href="<?php echo e(url('/create')); ?>"/>   
        <button class="btn btn-success">Adicionar Escola</button>
    </a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/index.blade.php ENDPATH**/ ?>