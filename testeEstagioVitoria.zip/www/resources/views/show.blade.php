@extends('templates.template')

@section('content')
<div class="col-8 m-auto">
    
    <h3 class="text-left">Dados Da Escola</h1>
    
    Id: {{$escola->id}} <br>
    Nome: {{$escola->nome}} <br>
    Localização: {{$escola->localizacao}} <br>
    <br>
    <a href="{{ url('teste/')}}"/>
                    <button class="btn btn-dark">Retornar a tela inicial</button>
</div>


@endsection