

<?php $__env->startSection('content'); ?>
<center>
    <h1>SchoolsAdmin</h1>
<div class="container"> 
 <div class="row">  
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      
      <?php if(session('danger')): ?>
        <div class="alert alert-danger">
          <?php echo e(session('danger')); ?>

        </div>
      <?php endif; ?>
     
  <div class="col-md-6 offset-md-3">
  <form method="POST" action="<?php echo e(url('/auth')); ?>" >
    <?php echo csrf_field(); ?>
    <div class="col-4">
    <label for="formGroupExampleInput">Endereço de email</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Seu email">
  </div>
<br>
  <div class="col-4">
    <label for="formGroupExampleInput2">Senha</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Senha">
  </div>
  <br>
  <button type="submit" class="btn btn-primary">Login</button>   
</form>
</div>
</div> 
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/login.blade.php ENDPATH**/ ?>