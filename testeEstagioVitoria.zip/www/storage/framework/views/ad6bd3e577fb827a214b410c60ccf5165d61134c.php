

<?php $__env->startSection('content'); ?>
<h3>Alterações feitas com sucesso</h3>
<a href="<?php echo e(url('/teste')); ?>"/> 
<button type="submit" class="btn btn-primary">
    Retornar a tela inicial
</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/AlteracoesSucesso.blade.php ENDPATH**/ ?>