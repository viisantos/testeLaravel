@extends('templates.template')

@section('content')
<h3>Cadastro feito com sucesso</h3>
<a href="{{ url('/teste')}}"/> 
<button type="submit" class="btn btn-primary">
    Retornar a tela inicial
</button>
@endsection