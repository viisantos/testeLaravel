<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelEscola extends Model
{
    use HasFactory;
    protected $table='escola';
    protected $fillable = ['id','nome','localizacao'];
    public $timestamps = false;
    
    public function relUsers(){
        return $this->hasMany('App\User','id_user','id');
    }
}
