

<?php $__env->startSection('content'); ?>
<div class="col-8 m-auto">
    
    <h3 class="text-left">Dados Da Escola</h1>
    
    Id: <?php echo e($escola->id); ?> <br>
    Nome: <?php echo e($escola->nome); ?> <br>
    Localização: <?php echo e($escola->localizacao); ?> <br>
    <br>
    <a href="<?php echo e(url('teste/')); ?>"/>
                    <button class="btn btn-dark">Retornar a tela inicial</button>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/show.blade.php ENDPATH**/ ?>