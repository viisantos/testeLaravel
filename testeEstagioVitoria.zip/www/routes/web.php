<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EscolasController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/teste', [EscolasController::class, 'index']);
Route::get('/teste/{id}', [EscolasController::class, 'show']);
Route::get('/create', [EscolasController::class, 'create']);
Route::post('/teste', 'App\Http\Controllers\EscolasController@store');
Route::get('/teste/{id}/edit', 'App\Http\Controllers\EscolasController@edit');
Route::post('/teste', [EscolasController::class, 'store']);
Route::put('/teste/{id}', [EscolasController::class, 'update']);
Route::post('excluir/{id}', 'App\Http\Controllers\EscolasController@destroy');
Route::get('excluir/{id}', 'App\Http\Controllers\EscolasController@delete');

Route::get('/login', 'App\Http\Controllers\EscolasController@login');
Route::post('/auth', 'App\Http\Controllers\EscolasController@auth');



