

<?php $__env->startSection('content'); ?>
<h3>Registro Excluído com sucesso</h3>
<a href="<?php echo e(url('/teste')); ?>"/> 
<button type="submit" class="btn btn-primary">
    Retornar
</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/ExcluidoSucesso.blade.php ENDPATH**/ ?>