@extends('templates.template')

@section('content')

<div class="col-8 m-auto">
    <h3 class="text-left">
        @if(isset($escola))
            Editar Escola
        @else
            Cadastrar Nova Escola
        @endif
    </h3>        
    @if(isset($escola))
           <form name="edit" id="id_edit" method="POST" action="{{ url("teste/$escola->id") }}">
           @method('PUT')
    @else
            <form name="cad" id="id_cad" method="POST" action="{{ url('/teste') }}">
    @endif    
        @csrf
      <div class="form-group">
        <label for="exampleInputEmail1">Id</label>
        <input type="Id" class="form-control" id="id_" aria-describedby="emailHelp" placeholder="Id" name="id" value="{{ $escola->id ?? ''}}">
      </div>
        <br>
      <div class="form-group">
        <label for="exampleInputEmail1">Nome</label>
        <input type="name" name="nome" class="form-control" id="exampleInputPassword1" placeholder="Nome" value="{{ $escola->nome ?? ''}}">
      </div>
        <br>
     <div class="form-group">
        <label for="exampleInputEmail1">Localização</label>
        <select class="form-control" name="localizacao" id="id_local">
            <option value="">
            </option>
                <option value="Rural" >
                    Rural
                </option>
                <option value="Urbana" >
                    Urbana
                </option>
                <option value="Quilombola" >
                    Quilombola
                </option>
                <option value="Prisional" >
                    Prisional
                </option>
                <option value="Assentamento" >
                    Assentamento
                </option>
        </select> 
         <br>
      </div>      
                
        <button type="submit" class="btn btn-success">
            @if(isset($escola)) Editar Escola @else Cadastrar Nova Escola @endif
        </button>
            
        <a href="{{ url('/teste')}}"/> 
        <button type="button" class="btn btn-primary">
            Retornar a tela inicial
        </button>  
</form>    
        
</div>
@endsection