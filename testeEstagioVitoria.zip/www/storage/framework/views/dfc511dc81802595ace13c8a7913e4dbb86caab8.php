

<?php $__env->startSection('content'); ?>

<div class="col-8 m-auto">
    <h3 class="text-left">
        <?php if(isset($escola)): ?>
            Editar Escola
        <?php else: ?>
            Cadastrar Nova Escola
        <?php endif; ?>
    </h3>        
    <?php if(isset($escola)): ?>
           <form name="edit" id="id_edit" method="POST" action="<?php echo e(url("teste/$escola->id")); ?>">
           <?php echo method_field('PUT'); ?>
    <?php else: ?>
            <form name="cad" id="id_cad" method="POST" action="<?php echo e(url('/teste')); ?>">
    <?php endif; ?>    
        <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="exampleInputEmail1">Id</label>
        <input type="Id" class="form-control" id="id_" aria-describedby="emailHelp" placeholder="Id" name="id" value="<?php echo e($escola->id ?? ''); ?>">
      </div>
        <br>
      <div class="form-group">
        <label for="exampleInputEmail1">Nome</label>
        <input type="name" name="nome" class="form-control" id="exampleInputPassword1" placeholder="Nome" value="<?php echo e($escola->nome ?? ''); ?>">
      </div>
        <br>
     <div class="form-group">
        <label for="exampleInputEmail1">Localização</label>
        <select class="form-control" name="localizacao" id="id_local">
            <option value="">
            </option>
                <option value="Rural" >
                    Rural
                </option>
                <option value="Urbana" >
                    Urbana
                </option>
                <option value="Quilombola" >
                    Quilombola
                </option>
                <option value="Prisional" >
                    Prisional
                </option>
                <option value="Assentamento" >
                    Assentamento
                </option>
        </select> 
         <br>
      </div>      
                
        <button type="submit" class="btn btn-success">
            <?php if(isset($escola)): ?> Editar Escola <?php else: ?> Cadastrar Nova Escola <?php endif; ?>
        </button>
            
        <a href="<?php echo e(url('/teste')); ?>"/> 
        <button type="button" class="btn btn-primary">
            Retornar a tela inicial
        </button>  
</form>    
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/create.blade.php ENDPATH**/ ?>