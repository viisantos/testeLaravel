

<?php $__env->startSection('content'); ?>

<div class="col-8 m-auto">
    <form name="exclui" id="id_exclui" method="post" action="<?php echo e(url("excluir/$escola->id")); ?>">
        <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="exampleInputEmail1">Deseja Mesmo Excluir o registro?</label>
      </div>
        <br>
      <div class="form-group">
        <label for="exampleInputEmail1">Nome</label>
        <input type="name" name="nome" class="form-control" disabled=true id="exampleInputPassword1" placeholder="Nome" value="<?php echo e($escola->nome ?? ''); ?>">
      </div>
        <br>    
        
        <button type="submit" class="btn btn-danger">
            Sim
        </button>
        
        <a href="<?php echo e(url('/teste')); ?>"/> 
        <button type="button" class="btn btn-primary">
            Retornar a tela inicial
        </button>
</form>        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\resources\views/delete.blade.php ENDPATH**/ ?>