@extends('templates.template')

@section('content')

<div class="col-8 m-auto">
    <form name="exclui" id="id_exclui" method="post" action="{{ url("excluir/$escola->id") }}">
        @csrf
      <div class="form-group">
        <label for="exampleInputEmail1">Deseja Mesmo Excluir o registro?</label>
      </div>
        <br>
      <div class="form-group">
        <label for="exampleInputEmail1">Nome</label>
        <input type="name" name="nome" class="form-control" disabled=true id="exampleInputPassword1" placeholder="Nome" value="{{ $escola->nome ?? ''}}">
      </div>
        <br>    
        
        <button type="submit" class="btn btn-danger">
            Sim
        </button>
        
        <a href="{{ url('/teste')}}"/> 
        <button type="button" class="btn btn-primary">
            Retornar a tela inicial
        </button>
</form>        
</div>
@endsection