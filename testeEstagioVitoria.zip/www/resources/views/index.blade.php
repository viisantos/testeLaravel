@extends('templates.template')

@section('content')
    <h1 class="text-left" class="titulo">SchoolsAdmin</h1>

<div class="col-8 m-auto">
    <table class="table text-center">
        <thead class="thead-dark">
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nome</th>
                <th scope="col">Localização</th>
                <th scope="col">Ação</th>
            </tr>   
        </thead>
        <tbody>
            @foreach($escola as $escolas)
            <tr>
                <th scope="row"> {{ $escolas->id}}</th>
                <td>{{ $escolas->nome}}</td>
                <td>{{ $escolas->localizacao}}</td>
                
                <td>
                    <a href="{{ url("teste/$escolas->id")}}"/>
                    <button class="btn btn-dark">Visualizar Detalhes</button>
                        
                    <a href="{{ url("teste/$escolas->id/edit")}}"/>
                    <button class="btn btn-primary">Editar</button>
                       
                    <a href="{{ url("excluir/$escolas->id")}}"/>
                    <button class="btn btn-danger">Excluir</button>
                </td>
            </tr>
            @endforeach        
        </tbody>
        </table>
    
        <a href="{{ url('/create')}}"/>   
        <button class="btn btn-success">Adicionar Escola</button>
    </a>
</div>

@endsection